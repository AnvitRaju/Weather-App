package com.example.weatherapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {
    FusedLocationProviderClient locationServices;
    ArrayList<Double> latAndLong = new ArrayList<>();
    String latitude;
    String longitude;
    EditText latInput;
    EditText longInput;
    Button submit;
    String currDay = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        locationServices = LocationServices.getFusedLocationProviderClient(this);
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_WEEK);
        switch (day) {
            case Calendar.SUNDAY:
                currDay = "Sun";
                break;
            case Calendar.MONDAY:
                currDay = "Mon";
                break;
            case Calendar.TUESDAY:
                currDay = "Tue";
                break;
            case Calendar.WEDNESDAY:
                currDay = "Wed";
                break;
            case Calendar.THURSDAY:
                currDay = "Thu";
                break;
            case Calendar.FRIDAY:
                currDay = "Fri";
                break;
            case Calendar.SATURDAY:
                currDay = "Sat";
                break;
        }
        //getCurrentLocation();
        latInput = (EditText) findViewById(R.id.lat);
        longInput = (EditText) findViewById(R.id.lon);
        submit = (Button) findViewById(R.id.go);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                latitude = latInput.getText().toString();
                longitude = longInput.getText().toString();
                latInput.setText(null);
                longInput.setText(null);
                latInput.setHint("Latitude");
                longInput.setHint("Longitude");
                requestWeatherData(latitude, longitude, currDay);
            }
        });
    }

    private void getCurrentLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationServices.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    System.out.println("location: " + location);
                    if (location != null) {
                        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
                        List<Address> addresses = null;
                        try {
                            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLatitude(), 1);
                            latAndLong.set(0,addresses.get(0).getLatitude());
                            latAndLong.set(1,addresses.get(0).getLongitude());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        }
        else {
            getPermission();
        }
    }

    private void getPermission() {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]
                {Manifest.permission.ACCESS_FINE_LOCATION},100);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode==100) {
            if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            }
            else {
                Toast.makeText(this, "Required Permission", Toast.LENGTH_SHORT).show();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void requestWeatherData(String latitude, String longitude, String day) {
        System.out.println("GETTING DATA");
        final TextView textView0 = (TextView) findViewById(R.id.currTemp);
        textView0.setVisibility(TextView.VISIBLE);
        final TextView textView1 = (TextView) findViewById(R.id.day1Temp);
        textView1.setVisibility(TextView.VISIBLE);
        final TextView textView2 = (TextView) findViewById(R.id.day2Temp);
        textView2.setVisibility(TextView.VISIBLE);
        final TextView textView3 = (TextView) findViewById(R.id.day3Temp);
        textView3.setVisibility(TextView.VISIBLE);
        final TextView textView4 = (TextView) findViewById(R.id.day4Temp);
        textView4.setVisibility(TextView.VISIBLE);
        final TextView textView5 = (TextView) findViewById(R.id.day5Temp);
        textView5.setVisibility(TextView.VISIBLE);
        final TextView textView6 = (TextView) findViewById(R.id.day6Temp);
        textView6.setVisibility(TextView.VISIBLE);
        final TextView textView7 = (TextView) findViewById(R.id.day7Temp);
        textView7.setVisibility(TextView.VISIBLE);
        final TextView textView8 = (TextView) findViewById(R.id.humidity);
        textView8.setVisibility(TextView.VISIBLE);
        final TextView textView9 = (TextView) findViewById(R.id.visibility);
        textView9.setVisibility(TextView.VISIBLE);
        final TextView textView10 = (TextView) findViewById(R.id.day1);
        textView10.setVisibility(TextView.VISIBLE);
        final TextView textView11 = (TextView) findViewById(R.id.day2);
        textView11.setVisibility(TextView.VISIBLE);
        final TextView textView12 = (TextView) findViewById(R.id.day3);
        textView12.setVisibility(TextView.VISIBLE);
        final TextView textView13 = (TextView) findViewById(R.id.day4);
        textView13.setVisibility(TextView.VISIBLE);
        final TextView textView14 = (TextView) findViewById(R.id.day5);
        textView14.setVisibility(TextView.VISIBLE);
        final TextView textView15 = (TextView) findViewById(R.id.day6);
        textView15.setVisibility(TextView.VISIBLE);
        final TextView textView16 = (TextView) findViewById(R.id.day7);
        textView16.setVisibility(TextView.VISIBLE);
        final TextView textView17 = (TextView) findViewById(R.id.currLocation);
        textView17.setVisibility(TextView.VISIBLE);
        final TextView textView18 = (TextView) findViewById(R.id.HumidityTitle);
        textView18.setVisibility(TextView.VISIBLE);
        final TextView textView19 = (TextView) findViewById(R.id.VisibilityTitle);
        textView19.setVisibility(TextView.VISIBLE);
        final TextView textView20 = (TextView) findViewById(R.id.forecast);
        textView20.setVisibility(TextView.VISIBLE);
        final TextView textView21 = (TextView) findViewById(R.id.coordinates);
        textView21.setVisibility(TextView.VISIBLE);

        List<String> daysOfWeek = Arrays.asList("Sun", "Mon", "Tue", "Wed","Thu","Fri","Sat");
        ArrayList<String> daysFromToday = new ArrayList<>();
        int numDaysCounted = 7;
        int currDayIndex = daysOfWeek.indexOf(day);
        while (numDaysCounted > 0) {
            daysFromToday.add(daysOfWeek.get(currDayIndex));
            currDayIndex += 1;
            if (currDayIndex == daysOfWeek.size()) {
                currDayIndex = 0;
            }
            numDaysCounted--;
        }

        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude + "&longitude=" + longitude + "&hourly=temperature_2m,relativehumidity_2m,visibility&daily=temperature_2m_max,temperature_2m_min&current_weather=true&temperature_unit=fahrenheit&timezone=GMT";
        System.out.println("url: " + url);
        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(JSONObject response) {
                ArrayList<String> dayMinTemps = new ArrayList<>();
                ArrayList<String> dayMaxTemps = new ArrayList<>();
                int currDayHumidity = 0;
                int currDayVisibility = 0;
                String currTemp = null;
                try {
                    JSONArray hourlyHumidity = response.getJSONObject("hourly").getJSONArray("relativehumidity_2m");
                    JSONArray hourlyVisibility = response.getJSONObject("hourly").getJSONArray("visibility");
                    JSONArray dailyMinTemps = response.getJSONObject("daily").getJSONArray("temperature_2m_min");
                    JSONArray dailyMaxTemps = response.getJSONObject("daily").getJSONArray("temperature_2m_max");
                    double currentTemp = response.getJSONObject("current_weather").getDouble("temperature");
                    currTemp = Integer.toString((int)currentTemp);
                    System.out.println("current temp: " + currTemp);
                    //get current humidity and visibility
                    currDayHumidity = hourlyHumidity.getInt(0);
                    currDayVisibility = hourlyVisibility.getInt(0);
                    //get min and max temperatures for each day in whole week
                    for (int i=0; i<dailyMinTemps.length(); i++) {
                        dayMinTemps.add(Integer.toString((int)dailyMinTemps.getDouble(i)));
                        dayMaxTemps.add(Integer.toString((int)dailyMaxTemps.getDouble(i)));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
                List<Address> addresses = null;
                System.out.println(latitude);
                System.out.println(longitude);
                try {
                    addresses = geocoder.getFromLocation(Double.parseDouble(latitude), Double.parseDouble(longitude), 1);

                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    textView17.setText(addresses.get(0).getLocality());
                } catch (IndexOutOfBoundsException   ex) {
                    textView17.setText("...");
                }
                String roundedLat = Math.round(Double.parseDouble(latitude) * 100.0) / 100.0+ "";
                String roundedLong = Math.round(Double.parseDouble(longitude) * 100.0) / 100.0+ "";


                textView0.setText(currTemp+"°");
                textView1.setText(dayMinTemps.get(0)+"° / "+ dayMaxTemps.get(0) + "°");
                textView2.setText(dayMinTemps.get(1)+"° / "+ dayMaxTemps.get(1) + "°");
                textView3.setText(dayMinTemps.get(2)+"° / "+ dayMaxTemps.get(2) + "°");
                textView4.setText(dayMinTemps.get(3)+"° / "+ dayMaxTemps.get(3) + "°");
                textView5.setText(dayMinTemps.get(4)+"° / "+ dayMaxTemps.get(4) + "°");
                textView6.setText(dayMinTemps.get(5)+"° / "+ dayMaxTemps.get(5) + "°");
                textView7.setText(dayMinTemps.get(6)+"° / "+ dayMaxTemps.get(6) + "°");
                textView8.setText(currDayHumidity+"%");
                textView9.setText(currDayVisibility/1609+" mi");
                textView10.setText("Today");
                textView11.setText(daysFromToday.get(1));
                textView12.setText(daysFromToday.get(2));
                textView13.setText(daysFromToday.get(3));
                textView14.setText(daysFromToday.get(4));
                textView15.setText(daysFromToday.get(5));
                textView16.setText(daysFromToday.get(6));
                textView21.setText(roundedLat + " | " + roundedLong);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView0.setText(error.getMessage());
                textView1.setText(error.getMessage());
                textView2.setText(error.getMessage());
                textView3.setText(error.getMessage());
                textView4.setText(error.getMessage());
                textView5.setText(error.getMessage());
                textView6.setText(error.getMessage());
                textView7.setText(error.getMessage());
                textView8.setText(error.getMessage());
                textView9.setText(error.getMessage());
                textView10.setText(error.getMessage());
                textView11.setText(error.getMessage());
                textView12.setText(error.getMessage());
                textView13.setText(error.getMessage());
                textView14.setText(error.getMessage());
                textView15.setText(error.getMessage());
                textView16.setText(error.getMessage());
                textView17.setText(error.getMessage());
                textView18.setText(error.getMessage());
                textView19.setText(error.getMessage());
                textView20.setText(error.getMessage());
                textView21.setText(error.getMessage());
            };
        });
        queue.add(jsonRequest);
    }
}